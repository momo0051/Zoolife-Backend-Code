<?php



namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Slider;
use App\Models\Item;
use App\Models\Category;

use Validator;
use Image;


class AdsController extends Controller

{
    

    public function index(Request $request){ 
    $page_title = 'Manage Slider';
    $ads = Item::get(); 
    
    return view('admin/ads/index', compact('page_title', 'ads'));    
   }

     public function create(Request $request){                 
       $page_title = 'Add Ads';
       $categories = Category::get();
       $subcategories = Category::get();
       /* dd($categories);*/
       return view('admin/ads/add', compact('page_title','categories','subcategories'));    
      }

     public function store(Request $request){
    
        $ads = new Item;
        
        $ads->itemTitle = $request->itemTitle;
        $ads->city = $request->city;
        $ads->category = $request->category;
        $ads->subCategory = $request->subCategory;
        $ads->itemDesc = $request->itemDesc;
        $ads->showPhoneNumber = $request->get('showPhoneNumber',0);
        $ads->showMessage = $request->get('showMessage',0);
        $ads->showComments = $request->get('showComments',0);
        $ads->phoneViewsCount = $request->get('phoneViewsCount',0);
        $ads->save();


      /*Save Multiple Images*/
      


       if ($request->hasFile('images')) {
           
         $images = $request->file('images');
           // /dd($images);
           foreach ($images as $k=> $image) {
            $fileName = time() . $k.'.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/ads/'), $fileName);
            $data[] =$fileName;

            if ($ads->image != 'photo.jpg' && is_file(public_path('uploads/ads/' . $ads->image))) {
                unlink(public_path('uploads/ads/' . $ads->main_image));
            }
           
          }
        
        }

        
        
        $ads->imagePath = implode(',',$data);
        
        $ads->save();
  
        
     return redirect()->route('admin.ads.show')->with('success', 'saved');

            
   }

    public function show($id) {
       $ads = Item::where('id', '=', $id)->first();
       //dd($ads);
       $categories = Category::get();
       $subcategories = Category::get();

       return view('admin/ads/edit', compact('ads','categories','subcategories'));    
    }

    


     public function update(Request $request, $id) {

        $ads = Item::where('id', '=', $id)->first();
        $ads->itemTitle = $request->itemTitle;
        $ads->city = $request->city;
        $ads->category = $request->category;
        $ads->subCategory = $request->subCategory;
        $ads->itemDesc = $request->itemDesc;
        $ads->showPhoneNumber = $request->get('showPhoneNumber',0);
        $ads->showMessage = $request->get('showMessage',0);
        $ads->showComments = $request->get('showComments',0);
        $ads->phoneViewsCount = $request->get('phoneViewsCount',0);
        $ads->save();

         /*Save Multiple Images*/
      


       if ($request->hasFile('images')) {
           
         $images = $request->file('images');
           // /dd($images);
           foreach ($images as $k=> $image) {
            $fileName = time() . $k.'.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/ads/'), $fileName);
            $data[] =$fileName;

            if ($ads->image != 'photo.jpg' && is_file(public_path('uploads/ads/' . $ads->image))) {
                unlink(public_path('uploads/ads/' . $ads->main_image));
            }
           
          }
        
        }

        
        
        $ads->imagePath = implode(',',$data);
        
        $ads->save();

        
         return redirect()->route('admin.ads.show')->with('success', 'saved');
    }


      public function destroy($id) {
        $ads = Item::find($id); 
        $ads->delete(); 
        return redirect()->route('admin.ads.show')->with('success', 'saved');
    }

   

 
    

}

