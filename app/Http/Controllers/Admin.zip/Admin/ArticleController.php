<?php



namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\Models\Article;
use Validator;
use Image;


class ArticleController extends Controller

{ 
    

    public function index(Request $request){ 
    $articles = Article::get();
    $page_title = 'Manage article';
    return view('admin/article/index', compact('page_title', 'articles'));    
   }

     public function create(Request $request){ 
                
       $page_title = 'Add article';
       return view('admin/article/add', compact('page_title'));    
      }

     public function store(Request $request){ 

      $this->validate($request, [
         'title' => 'required',
         'description' => 'required',
         'date' => 'required',
         'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
     ]);

      $article = new Article;
      $article->title = $request->title;
      $article->description = $request->description;
      $article->date = $request->date;
      
      $article->save();

      if ($request->hasFile('image')) {
            $image = $request->file('image');
            $fileName = time() . "article." . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/article/'), $fileName);

            if ($article->image != 'photo.jpg' && is_file(public_path('uploads/article/' . $article->image))) {
                unlink(public_path('uploads/article/' . $article->image));
            }
            $article->image = $fileName;
            $article->save();
        }
     return redirect()->route('admin.article.show')->with('success', 'saved');
            
   }

     public function show($id) {
      $article = Article::where('id', '=', $id)->first();        
      return view('admin/article/edit', compact('article'));    
    }

     public function update(Request $request, $id) {
     
       $this->validate($request, [
         'title' => 'required',
         'description' => 'required',
         'date' => 'required',
         /*'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'*/
     ]);
      
      $article = Article::where('id', '=', $id)->first();
      $article->title = $request->title;
      $article->description = $request->description;
      $article->date = $request->date;
      
      $article->save();
      if ($request->hasFile('image')) {
            $image = $request->file('image');
            $fileName = time() . "article." . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/article/'), $fileName);

            if ($article->image != 'photo.jpg' && is_file(public_path('uploads/article/' . $article->image))) {
                unlink(public_path('uploads/article/' . $article->image));
            }
            $article->image = $fileName;
            $article->save();
        }
      return redirect()->route('admin.article.show')->with('success', 'saved');
    }


      public function destroy($id) {
        $p = Article::find($id); 
        $p->delete(); //delete the client
        return redirect()->route('admin.article.show')->with('success', 'saved');
    }


    

}

