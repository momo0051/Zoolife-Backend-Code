<?php



namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\Models\Account;
use Validator;
use Image;
use App\Models\User;

class AccountController extends Controller

{

  
    

    public function index(Request $request){ 
    $accounts = User::get();
    //dd($products);
    $page_title = 'Manage accounts';
    return view('admin/account/index', compact('page_title', 'accounts'));    
   }

     public function create(Request $request){ 
                
       $page_title = 'Add accounts';
       return view('admin/account/add', compact('page_title'));    
      }

     public function store(Request $request){ 

      $this->validate($request, [
         'name' => 'required',
         'username' => 'required',
         'contact_no' => 'required',
         'password' => 'min:6',
         'confirm_password' => 'required_with:password|same:password|min:6'
     ]);

      $account = new User;
      $account->fullname = $request->name;
      $account->login = $request->username;
      $account->phone = $request->contact_no;
      $account->passw = $request->password;
        if($request->get('status',0) == 1)
      {
          $account->status ='Yes';
      }
      else
      {
          $account->status ='No';
      }
      $account->save();
     return redirect()->route('admin.account.show')->with('success', 'saved');
            
   }

     public function show($id) {
      $account = User::where('id', '=', $id)->first();        
      return view('admin/account/edit', compact('account'));    
    }

     public function update(Request $request, $id) {
      
      $account = User::where('id', '=', $id)->first();
      $account->fullname = $request->name;
      $account->login = $request->username;
      $account->phone = $request->contact_no;
      if($request->get('status',0) == 1)
      {
          $account->status ='Yes';
      }
      else
      {
          $account->status ='No';
      }
     
      if(empty($request->password)){
       $account->passw = $request->oldpassword;
      }else{
        $account->passw = $request->password;
      }
      
      
      $account->save();
      return redirect()->route('admin.account.show')->with('success', 'saved');
    }


      public function destroy($id) {
        $p = User::find($id); 
        $p->delete(); //delete the client
        return redirect()->route('admin.account.show')->with('success', 'saved');
    }


    

}

